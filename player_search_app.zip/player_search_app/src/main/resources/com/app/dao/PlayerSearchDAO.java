package com.app.dao;

public interface PlayerSearchDAO {

}
